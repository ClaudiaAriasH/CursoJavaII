package com.com.udem.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CruduserApplicationTests {

	@Test
	void contextLoads() {
	}

}
