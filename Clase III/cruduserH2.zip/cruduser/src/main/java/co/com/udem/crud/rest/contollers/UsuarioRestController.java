package co.com.udem.crud.rest.contollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import co.com.udem.crud.entities.Usuario;
import co.com.udem.crud.repositories.UsuarioRepository;

@RestController
public class UsuarioRestController {

	@Autowired
	private UsuarioRepository usuarioRepository;

	/*
	 * public UsuarioRestController(UsuarioRepository usuarioRepository) { super();
	 * this.usuarioRepository = usuarioRepository; }
	 */

	@PostMapping("/usuarios/adicionarUsuario")
	public ResponseEntity<String> adicionarUsuario(@RequestBody Usuario usuario) {
		usuarioRepository.save(usuario);
		return ResponseEntity.ok("Registro guardado de forma exitosa");
	}

	@GetMapping("/usuarios")
	public Iterable<Usuario> listarUsuarios() {
		return usuarioRepository.findAll();
	}

	@DeleteMapping("/usuarios/{id}")
	public ResponseEntity<String> eliminarUsuario(@PathVariable Long id) {
		usuarioRepository.deleteById(id);
		return ResponseEntity.ok("Registro eliminado de forma exitosa");
	}

	@GetMapping("/usuarios/{id}")
	public Usuario buscarUsuario(@PathVariable Long id) {
		return usuarioRepository.findById(id).get();
	}
	
	@PutMapping("/users/{id}")
    public ResponseEntity<Object> updateUser(@RequestBody Usuario newUser, @PathVariable Long id) {
        if(usuarioRepository.findById(id).isPresent()) {
            Usuario user = usuarioRepository.findById(id).get();
            user.setFirsName(newUser.getFirsName());
            user.setLastName(newUser.getLastName());
            user.setEmail(newUser.getEmail());
            usuarioRepository.save(user);
            return ResponseEntity.ok("Se actualizó exitosamente");
        }else {
            return null;
        }
    }
}
