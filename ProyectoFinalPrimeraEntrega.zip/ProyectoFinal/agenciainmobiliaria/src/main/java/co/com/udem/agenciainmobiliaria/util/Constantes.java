package co.com.udem.agenciainmobiliaria.util;

public class Constantes {

	public static final String CODIGO_HTTP = "codigoHttp";
	public static final String MENSAJE_EXITO = "mensajeExito";
	public static final String MENSAJE_ERROR = "mensajeError";

	private Constantes() {
		super();

	}

}
