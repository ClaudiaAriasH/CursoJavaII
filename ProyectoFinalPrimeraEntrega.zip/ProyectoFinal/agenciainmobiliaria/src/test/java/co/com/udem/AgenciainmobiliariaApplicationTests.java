package co.com.udem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgenciainmobiliariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
